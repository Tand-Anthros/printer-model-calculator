import React from 'react';
import ReactDOM from 'react-dom';
import TableContext from './App';

// Рендеринг корневого компонента React
ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

//чистка консоли после запуска
window.onload = function() {
  console.clear();
};
